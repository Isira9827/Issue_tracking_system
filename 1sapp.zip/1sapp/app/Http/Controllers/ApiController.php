<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\issues;
use App\Models\Category;
class ApiController extends Controller
{

    public function __construct()
    {
        $this->middleware(['auth:api-system-user'])->except([
            'create'
      ]);
    }

    public function create(Request $request)
    {
        $issues = new Issues();

        $issues->title = $request->input('title');
        $issues->body = $request->input('body');
        $issues->uuid = $request->input('uuid');
        $issues->slug = $request->input('slug');

        $issues->save();
        return response()->json($issues);
    }

    public function createSub(Request $request)
    {
        $sub = new Subcategory();

        $sub->category_id = $request->input('category_id');
        $sub->name = $request->input('name');
        $sub->description = $request->input('description');

        $sub->save();
        return response()->json($sub);
    }

    public function getCategories(){
        $category = Category::with('subCategory')->get();
        dd($category);
    }

    public function getComments(){
        $comments = Issues::with('comments')->get();
        dd($comments);
    }

    public function getImages(){
        $images = Issues::with('images')->get();
        dd($images);
    }

    

}
