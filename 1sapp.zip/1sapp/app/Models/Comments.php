<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class comments extends Model
{
    use HasFactory;

    protected $fillable = ['issue_id','body'];

    public function issues(){
        return $this->belongsTo(Issues::class);
    }

    public function images(){
        return $this->hasMany(Images::class);
    }

}
