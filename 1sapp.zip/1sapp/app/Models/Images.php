<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class images extends Model
{
    use HasFactory;

    protected $fillable = ['imagable_type','imagable_id','size','path','name','extension'];

    public function issues(){
        return $this->belongsTo(Issues::class);
    }

    public function comments(){
        return $this->belongsTo(Comments::class);
    }


}
